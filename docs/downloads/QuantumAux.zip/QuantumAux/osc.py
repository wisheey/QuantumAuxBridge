"""Small OSC 1.0 codec. Supports messages and nested bundles, no dependencies."""
import math
import struct


def string(value):
    raw = value.encode('utf-8') + b'\0'
    return raw + b'\0' * (-len(raw) % 4)


def encode(address, value=None):
    if not address.startswith('/') or '\0' in address:
        raise ValueError('Invalid OSC address')
    if value is None:
        return string(address) + string(',')
    if isinstance(value, str):
        return string(address) + string(',s') + string(value)
    if type(value) is int:
        return string(address) + string(',i') + struct.pack('>i', value)
    if not math.isfinite(value):
        raise ValueError('Non-finite OSC value')
    return string(address) + string(',f') + struct.pack('>f', value)


def decode(packet, depth=0):
    if depth > 8 or len(packet) > 65535:
        raise ValueError('OSC limit exceeded')
    if packet.startswith(b'#bundle\0'):
        if len(packet) < 16:
            raise ValueError('Truncated bundle')
        messages, offset = [], 16
        while offset < len(packet):
            if offset + 4 > len(packet):
                raise ValueError('Truncated bundle size')
            size = struct.unpack_from('>I', packet, offset)[0]
            offset += 4
            if not size or offset + size > len(packet):
                raise ValueError('Invalid bundle size')
            messages.extend(decode(packet[offset:offset + size], depth + 1))
            offset += size
        return messages

    def read_string(offset):
        end = packet.index(b'\0', offset)
        result = packet[offset:end].decode('utf-8')
        next_offset = (end + 4) & ~3
        if next_offset > len(packet):
            raise ValueError('Truncated OSC string')
        return result, next_offset

    address, offset = read_string(0)
    tags, offset = read_string(offset)
    if not address.startswith('/') or not tags.startswith(','):
        raise ValueError('Invalid OSC message')
    args = []
    for tag in tags[1:]:
        if tag in 'if':
            if offset + 4 > len(packet):
                raise ValueError('Truncated argument')
            value = struct.unpack_from('>' + tag, packet, offset)[0]
            offset += 4
        elif tag == 's':
            value, offset = read_string(offset)
        elif tag in 'TF':
            value = 1 if tag == 'T' else 0
        else:
            raise ValueError('Unsupported OSC type')
        args.append(value)
    return [(address, args)]
