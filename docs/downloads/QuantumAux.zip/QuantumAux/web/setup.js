'use strict';
const $=id=>document.getElementById(id);
let initialized=false;
async function request(payload) {
 const response=await fetch('/api/setup',{method:payload?'POST':'GET',cache:'no-store',headers:payload?{'Content-Type':'application/json'}:{},body:payload?JSON.stringify(payload):undefined,signal:AbortSignal.timeout(6000)});
 const result=await response.json();if(!response.ok)throw Error(result.error);return result;
}
function show(data) {
 $('message').textContent=data.connection.opened ? (data.connection.connected ? 'Connection opened. Receiving live console data.' : 'Connection opened. Waiting for real console data…') : 'Connection not opened. Connect to the console below.';
 if(!initialized){$('ip').value=data.config.console_ip;$('consoleport').value=data.config.console_receive_port;$('localport').value=data.config.bridge_receive_port;initialized=true;}
 $('console-name').textContent=data.connection.console_name || (data.connection.connected?'Console replying':'Waiting for console');
 $('diagnostics').textContent=`${data.connection.message} Input names: ${data.input_names_loaded}/${data.inputs_discovered??'unknown'}. OSC messages received: ${data.connection.received_messages}. Last address: ${data.connection.last_address??'none'}.`;
 $('aux-list').replaceChildren();
 for(const aux of data.auxes){
  const card=document.createElement('article');card.className='aux-item';
  const label=document.createElement('h3');label.textContent=`Aux ${aux.id} · ${aux.name===null?'Waiting for console name':aux.name || '(unnamed on console)'}`;
  const mode=document.createElement('p');mode.textContent=aux.supported?(aux.stereo?'Stereo':'Mono'):`Unsupported bus mode ${aux.mode} — controls disabled`;
  const occupancy=document.createElement('strong');occupancy.textContent=aux.occupied?'In use':'Available';
  card.append(label,mode,occupancy);$('aux-list').append(card);
 }
}
$('connect').onsubmit=async e=>{e.preventDefault();const button=$('connect').querySelector('button');button.disabled=true;
 try{show(await request({console_ip:$('ip').value.trim(),console_receive_port:Number($('consoleport').value),bridge_receive_port:Number($('localport').value)}));}
 catch(e){$('message').textContent=e.message;}finally{button.disabled=false;}};
async function loop(){try{show(await request());}catch(e){$('diagnostics').textContent=e.message;}setTimeout(loop,1500);}loop();
