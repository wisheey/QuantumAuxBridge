param([Parameter(Mandatory=$true)][string]$StatusFile)
$ErrorActionPreference = 'Stop'
function Status($message) { [IO.File]::WriteAllText($StatusFile, $message) }
try {
    $version = '3.13.16'
    # Windows 10 ARM supports x86 emulation; do not assume x64 emulation.
    $nativeArch = if ($env:PROCESSOR_ARCHITEW6432) { $env:PROCESSOR_ARCHITEW6432 } else { $env:PROCESSOR_ARCHITECTURE }
    $arch = if ($nativeArch -eq 'ARM64') { 'win32' } elseif ([Environment]::Is64BitOperatingSystem) { 'amd64' } else { 'win32' }
    $cache = Join-Path $env:LOCALAPPDATA "QuantumAux\Python-$version-$arch"
    $python = Join-Path $cache 'pythonw.exe'
    if (!(Test-Path $python)) {
        Status 'Downloading Python runtime (first launch only)...'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $temporary = "$cache.download-$([Guid]::NewGuid().ToString('N'))"
        New-Item -ItemType Directory -Path $temporary -Force | Out-Null
        $zip = Join-Path $temporary 'python.zip'
        Invoke-WebRequest -UseBasicParsing -Uri "https://www.python.org/ftp/python/$version/python-$version-embed-$arch.zip" -OutFile $zip -TimeoutSec 180
        Status 'Preparing private Python runtime...'
        $unpacked = Join-Path $temporary 'runtime'
        Expand-Archive -LiteralPath $zip -DestinationPath $unpacked
        foreach ($name in @('python.exe','pythonw.exe')) {
            $signature = Get-AuthenticodeSignature (Join-Path $unpacked $name)
            if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
                throw 'Python publisher verification failed. Check Windows certificates and internet access.'
            }
        }
        New-Item -ItemType Directory -Path (Split-Path $cache) -Force | Out-Null
        if (Test-Path $cache) { Remove-Item -LiteralPath $cache -Recurse -Force }
        Move-Item -LiteralPath $unpacked -Destination $cache
        Remove-Item -LiteralPath $temporary -Recurse -Force
    }
    # Embeddable Python isolates imports. Add this app explicitly without enabling site/pip.
    $pth = Get-ChildItem -LiteralPath $cache -Filter 'python*._pth' | Select-Object -First 1
    if (!$pth) { throw 'Python runtime import configuration is missing.' }
    $zipName = (Get-ChildItem -LiteralPath $cache -Filter 'python*.zip' | Select-Object -First 1).Name
    [IO.File]::WriteAllLines($pth.FullName, @($zipName, '.', $PSScriptRoot), (New-Object Text.UTF8Encoding($false)))
    Status "READY|$python"
} catch {
    Status "ERROR|$($_.Exception.Message)"
    exit 1
}
