"""Windowless entrypoint: retain tracebacks in a log instead of a console window."""
import sys
from pathlib import Path

if __name__ == '__main__':
    log = Path(__file__).resolve().parent / 'server.log'
    with log.open('a', encoding='utf-8', buffering=1) as stream:
        sys.stdout = sys.stderr = stream
        import traceback
        try:
            from server import main
            main()
        except BaseException:
            traceback.print_exc()
            raise
