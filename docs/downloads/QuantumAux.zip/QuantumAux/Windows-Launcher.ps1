$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$created = $false
$mutex = New-Object Threading.Mutex($true, 'Local\QuantumAuxDesktop', [ref]$created)
if (!$created) {
    [Windows.Forms.MessageBox]::Show('Quantum Aux is already open. Look for its tray icon.', 'Quantum Aux') | Out-Null
    $mutex.Dispose(); exit
}
$script:child = $null
$script:installer = $null
$script:python = $null
$script:port = 8765
$script:ready = $false
$script:openSetupPending = $false
$runningIcon = New-Object Drawing.Icon((Join-Path $PSScriptRoot 'icons\running.ico'))
$stoppedIcon = New-Object Drawing.Icon((Join-Path $PSScriptRoot 'icons\stopped.ico'))
$script:quitting = $false
$script:stopFile = Join-Path $env:TEMP "QuantumAux-stop-$([Guid]::NewGuid().ToString('N'))"
$script:runtimeStatus = Join-Path $env:TEMP "QuantumAux-runtime-$([Guid]::NewGuid().ToString('N')).txt"
$script:serverStatus = Join-Path $env:TEMP "QuantumAux-server-$([Guid]::NewGuid().ToString('N')).json"
$script:lastError = ''
$script:startupAt = [DateTime]::UtcNow
$script:stopAt = $null
$form = New-Object Windows.Forms.Form
$form.Text = 'Quantum Aux Server'
$form.ClientSize = New-Object Drawing.Size(470, 285)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Icon = [Drawing.SystemIcons]::Application
$status = New-Object Windows.Forms.Label
$status.Location = New-Object Drawing.Point(18, 18)
$status.Size = New-Object Drawing.Size(435, 48)
$status.Font = New-Object Drawing.Font('Segoe UI', 11)
$status.Text = 'Preparing server...'
$form.Controls.Add($status)
$addresses = New-Object Windows.Forms.TextBox
$addresses.Location = New-Object Drawing.Point(18, 78)
$addresses.Size = New-Object Drawing.Size(435, 66)
$addresses.Multiline = $true; $addresses.ReadOnly = $true
$form.Controls.Add($addresses)
function Button($text, $x, $y, $width) {
    $button = New-Object Windows.Forms.Button
    $button.Text = $text; $button.Location = New-Object Drawing.Point($x,$y)
    $button.Size = New-Object Drawing.Size($width,34)
    $form.Controls.Add($button); return $button
}
$start = Button 'Start server' 18 158 135
$setup = Button 'Console setup' 167 158 135
$mixer = Button 'Open mixer' 316 158 135
$hide = Button 'Hide to tray' 18 205 135
$logs = Button 'View log' 167 205 135
$quit = Button 'Exit server' 316 205 135
$setup.Enabled = $false; $mixer.Enabled = $false; $start.Enabled = $false
$tray = New-Object Windows.Forms.NotifyIcon
$tray.Icon = $stoppedIcon; $tray.Text = 'Quantum Aux: preparing'; $tray.Visible = $true
$menu = New-Object Windows.Forms.ContextMenuStrip
$showItem = $menu.Items.Add('Show server')
$setupItem = $menu.Items.Add('Console setup')
$mixerItem = $menu.Items.Add('Open mixer')
$stopItem = $menu.Items.Add('Stop server')
$exitItem = $menu.Items.Add('Exit')
$tray.ContextMenuStrip = $menu
function Show-Server { $form.Show(); $form.WindowState = 'Normal'; $form.Activate() }
function Log-Launcher($message) {
    Add-Content -LiteralPath (Join-Path $PSScriptRoot 'server.log') -Value ("[Launcher {0}] {1}" -f [DateTime]::Now.ToString('s'), $message)
}
function Open-Browser($url) {
    try {
        $info = New-Object Diagnostics.ProcessStartInfo
        $info.FileName = $url; $info.UseShellExecute = $true
        [Diagnostics.Process]::Start($info) | Out-Null
        Log-Launcher "Opened browser: $url"
        return $true
    } catch {
        try {
            $shell = New-Object -ComObject Shell.Application
            $shell.ShellExecute($url)
            Log-Launcher "Opened browser via Windows shell: $url"
            return $true
        } catch { Log-Launcher "Browser launch failed: $($_.Exception.Message)"; return $false }
    }
}
function Open-Setup { if ($script:ready) { return (Open-Browser "http://localhost:$($script:port)/setup") }; return $false }
function Open-Mixer { if ($script:ready) { Open-Browser "http://localhost:$($script:port)/" | Out-Null } }
function Read-State {
    if (!(Test-Path $script:serverStatus)) { throw 'Waiting for desktop server status.' }
    if (([DateTime]::UtcNow - (Get-Item -LiteralPath $script:serverStatus).LastWriteTimeUtc).TotalSeconds -gt 5) { throw 'Desktop server status is stale.' }
    $data = [IO.File]::ReadAllText($script:serverStatus) | ConvertFrom-Json
    if ($data.pid -ne $script:child.Id) { throw 'Desktop status is from a different server process.' }
    $script:port = [int]$data.port
    return $data
}
function Start-Server {
    if (!$script:python -or ($script:child -and !$script:child.HasExited)) { return }
    try {
        $script:port = 8765
        $config = Join-Path $PSScriptRoot 'config.live.json'
        if (Test-Path $config) { $script:port = [int](Get-Content -LiteralPath $config -Raw | ConvertFrom-Json).http_port }
        # Do not take over an unrelated process or mistake it for our own server.
        $probe = New-Object Net.Sockets.TcpClient
        $inUse = $false
        try {
            $pending = $probe.ConnectAsync('127.0.0.1', $script:port)
            $inUse = $pending.Wait(250) -and $probe.Connected
        } catch { } finally { $probe.Dispose() }
        if ($inUse) { throw "Port $($script:port) is already in use. Close the previous server first." }
        Remove-Item -LiteralPath $script:stopFile,$script:serverStatus -ErrorAction SilentlyContinue
        $arguments = '"' + (Join-Path $PSScriptRoot 'desktop_server.py') + '" --stop-file "' + $script:stopFile + '" --status-file "' + $script:serverStatus + '"'
        $script:child = Start-Process -FilePath $script:python -ArgumentList $arguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru
        $script:startupAt = [DateTime]::UtcNow; $script:stopAt = $null; $script:openSetupPending = $true
        $start.Text = 'Stop server'; $status.Text = 'Starting server...'
    } catch { $status.Text = $_.Exception.Message; $tray.Text = 'Quantum Aux: start failed' }
}
function Stop-Server {
    if ($script:child -and !$script:child.HasExited) {
        [IO.File]::WriteAllText($script:stopFile, 'stop')
        $script:stopAt = [DateTime]::UtcNow
        $status.Text = 'Stopping server...'; $start.Enabled = $false; $tray.Icon = $stoppedIcon; $script:openSetupPending = $false
    }
}
$start.Add_Click({ if ($script:child -and !$script:child.HasExited) { Stop-Server } else { Start-Server } })
$setup.Add_Click({ Open-Setup | Out-Null }); $setupItem.Add_Click({ Open-Setup | Out-Null })
$mixer.Add_Click({ Open-Mixer }); $mixerItem.Add_Click({ Open-Mixer })
$hide.Add_Click({ $form.Hide() }); $showItem.Add_Click({ Show-Server }); $tray.Add_DoubleClick({ Show-Server })
$stopItem.Add_Click({ Stop-Server })
$logs.Add_Click({
    $log = Join-Path $PSScriptRoot 'server.log'
    if (Test-Path $log) { Start-Process notepad.exe -ArgumentList ('"' + $log + '"') }
})
$quit.Add_Click({ $script:quitting = $true; $form.Close() })
$exitItem.Add_Click({ $script:quitting = $true; $form.Close() })
$form.Add_FormClosing({
    param($sender,$event)
    if (!$script:quitting) { $event.Cancel = $true; $form.Hide() }
})
$timer = New-Object Windows.Forms.Timer
$timer.Interval = 1000
$timer.Add_Tick({
    try {
        if ($script:installer) {
            if (Test-Path $script:runtimeStatus) {
                $message = [IO.File]::ReadAllText($script:runtimeStatus)
                if ($message.StartsWith('READY|')) {
                    $script:python = $message.Substring(6); $script:installer = $null
                    $start.Enabled = $true; Start-Server
                } elseif ($message.StartsWith('ERROR|')) {
                    $status.Text = $message.Substring(6); $tray.Text = 'Quantum Aux: runtime setup failed'
                    $script:installer = $null; $start.Text = 'Retry setup'; $start.Enabled = $false
                    [Windows.Forms.MessageBox]::Show($status.Text + "`r`nClose and reopen the launcher to retry.", 'Runtime setup failed') | Out-Null
                } else { $status.Text = $message }
            }
            return
        }
        $alive = $script:child -and !$script:child.HasExited
        if ($script:stopAt -and $alive) {
            if (([DateTime]::UtcNow - $script:stopAt).TotalSeconds -gt 5) { $script:child.Kill() }
            return
        }
        $script:ready = $false
        if ($alive) {
            try {
                $state = Read-State
                $script:ready = $true
                if ($script:openSetupPending) {
                    if (Open-Setup) { $script:openSetupPending = $false }
                }
                # The socket-open state is the sole green condition, shared with setup.
                if ($state.connection.opened -eq $true) {
                    $tray.Icon = $runningIcon
                    if ($state.connection.connected) {
                        $status.Text = 'Connection opened - console LIVE'
                        $tray.Text = 'Quantum Aux: connection opened, console LIVE'
                    } else {
                        $status.Text = 'Connection opened - waiting for real console data'
                        $tray.Text = 'Quantum Aux: connection opened'
                    }
                } else {
                    $status.Text = 'Server ready - open console connection in setup'
                    $tray.Icon = $stoppedIcon
                    $tray.Text = 'Quantum Aux: console connection not open'
                }
            } catch {
                $status.Text = 'Waiting for server status...'; $tray.Icon = $stoppedIcon
                if ($script:lastError -ne $_.Exception.Message) {
                    $script:lastError = $_.Exception.Message; Log-Launcher $script:lastError
                }
                if (([DateTime]::UtcNow - $script:startupAt).TotalSeconds -gt 15) { $status.Text = 'Server not responding. Stop it and check View log.' }
            }
        } else {
            $start.Text = 'Start server'; $start.Enabled = $true; $tray.Icon = $stoppedIcon
            $tray.Text = 'Quantum Aux: server stopped'
            if ($script:stopAt) { $status.Text = 'Server stopped'; $script:stopAt = $null }
            elseif ($script:child) { $status.Text = 'Server exited. Open View log for the reason.' }
        }
        $setup.Enabled = $script:ready; $mixer.Enabled = $script:ready
        $setupItem.Enabled = $script:ready; $mixerItem.Enabled = $script:ready; $stopItem.Enabled = $alive
        if ($script:ready) {
            $ips = [Net.Dns]::GetHostAddresses([Net.Dns]::GetHostName()) | Where-Object { $_.AddressFamily -eq 'InterNetwork' -and !$_.ToString().StartsWith('127.') }
            $addresses.Text = "iPad / musician browser addresses:`r`n" + (($ips | ForEach-Object { "http://$($_):$($script:port)" }) -join '   ')
        }
    } catch { $status.Text = $_.Exception.Message }
})
try {
    $args = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $PSScriptRoot 'setup-runtime.ps1') + '" -StatusFile "' + $script:runtimeStatus + '"'
    $script:installer = Start-Process powershell.exe -ArgumentList $args -WindowStyle Hidden -PassThru
    $timer.Start()
    [Windows.Forms.Application]::Run($form)
} finally {
    $timer.Stop(); $timer.Dispose()
    if ($script:installer -and !$script:installer.HasExited) { $script:installer.Kill() }
    if ($script:child -and !$script:child.HasExited) {
        [IO.File]::WriteAllText($script:stopFile, 'stop')
        if (!$script:child.WaitForExit(5000)) { $script:child.Kill() }
    }
    $tray.Visible = $false; $tray.Dispose(); $menu.Dispose(); $runningIcon.Dispose(); $stoppedIcon.Dispose()
    Remove-Item -LiteralPath $script:stopFile,$script:runtimeStatus,$script:serverStatus -ErrorAction SilentlyContinue
    $mutex.ReleaseMutex(); $mutex.Dispose()
}
