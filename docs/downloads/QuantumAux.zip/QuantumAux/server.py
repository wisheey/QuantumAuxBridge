#!/usr/bin/env python3
"""Quantum Aux: live DiGiCo Pad OSC bridge. Python standard library only."""
import argparse
import ipaddress
import json
import math
import re
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from osc import encode, decode

ROOT = Path(__file__).resolve().parent
# Discovery bounds include large Quantum engines without hard-coding a model.
MAX_INPUTS = 512
MAX_AUXES = 256
FIELDS = {'level': 'send_level', 'pan': 'send_pan'}
DEFAULT = {'version': 3, 'console_ip': '', 'console_receive_port': 8000,
           'bridge_receive_port': 9000, 'http_port': 8765, 'max_db': 10.0}


def validate(config):
    if config['console_ip']:
        address = ipaddress.IPv4Address(config['console_ip'])
        if address.is_multicast or address.is_unspecified or str(address) == '255.255.255.255':
            raise ValueError('Enter the console unicast IPv4 address.')
    for key in ('console_receive_port', 'bridge_receive_port', 'http_port'):
        if type(config[key]) is not int or not 1024 <= config[key] <= 65535:
            raise ValueError('Ports must be whole numbers between 1024 and 65535.')
    if type(config['max_db']) not in (int, float) or not math.isfinite(config['max_db']) or not -60 <= config['max_db'] <= 10:
        raise ValueError('The send ceiling must be between -60 and +10 dB.')


class Bridge:
    def __init__(self, config, path=None):
        config = {**config, 'max_db': 10.0}
        validate(config)
        self.config, self.path = dict(config), path
        self.config.pop('aux_access', None)
        self.lock = threading.RLock()
        self.sock = None
        self.stop_event = threading.Event()
        self.threads = []
        self.revision = 0
        self.clear()

    def clear(self):
        self.revision += 1
        self.leases = {}
        self.inputs, self.auxes, self.values, self.active = {}, {}, {}, {}
        self.name = None
        self.input_count = None
        self.modes = None
        self.last_rx = 0
        self.received = 0
        self.last_address = None
        self.last_error = None
        self.query_times, self.last_writes = {}, {}
        self.started = time.monotonic()

    def save(self):
        if self.path:
            temporary = self.path.with_suffix('.tmp')
            temporary.write_text(json.dumps(self.config, indent=2) + '\n')
            temporary.replace(self.path)

    def configure(self, patch):
        expected = {'console_ip', 'console_receive_port', 'bridge_receive_port'}
        if not isinstance(patch, dict) or set(patch) != expected:
            raise ValueError('Enter the console address and both UDP ports.')
        config = {**self.config, **patch}
        validate(config)
        if not config['console_ip']:
            raise ValueError('Enter the console IPv4 address.')
        self.stop()
        with self.lock:
            self.config = config
            self.clear()
            self.save()
        self.start()

    def start(self):
        if not self.config['console_ip']:
            return
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.bind(('0.0.0.0', self.config['bridge_receive_port']))
        except OSError:
            sock.close()
            self.last_error = 'Cannot bind the receive port. Close the app using it or choose another port.'
            raise
        sock.settimeout(.3)
        self.sock = sock
        event = threading.Event(); self.stop_event = event
        self.threads = [threading.Thread(target=self.listen, args=(sock, event), daemon=True),
                        threading.Thread(target=self.poll, args=(sock, event), daemon=True)]
        for thread in self.threads:
            thread.start()

    def stop(self):
        self.stop_event.set()
        if self.sock:
            self.sock.close()
        for thread in self.threads:
            thread.join(timeout=1)
        self.threads = []; self.sock = None

    LEASE_SECONDS = 30

    def expire_leases(self):
        now = time.monotonic()
        for aux, lease in list(self.leases.items()):
            if lease['expires'] <= now:
                del self.leases[aux]
                self.active.pop(aux, None)

    def claim(self, aux):
        with self.lock:
            self.expire_leases()
            if type(aux) is not int or aux not in self.auxes:
                raise ValueError('Choose an available aux.')
            info = self.auxes[aux]
            if not info['supported'] or info['name'] is None or not self.connection_info()['connected']:
                raise RuntimeError('This aux is not ready. Wait for console feedback.')
            if aux in self.leases:
                raise RuntimeError('This mix is already in use. Choose another available mix.')
            token = secrets.token_urlsafe(32)
            self.leases[aux] = {'token': token, 'expires': time.monotonic() + self.LEASE_SECONDS}
            self.active[aux] = time.monotonic()
            return {'token': token, 'aux': aux, 'lease_seconds': self.LEASE_SECONDS}

    def authorize(self, token):
        with self.lock:
            self.expire_leases()
            for aux, lease in self.leases.items():
                if secrets.compare_digest(str(token), lease['token']):
                    lease['expires'] = time.monotonic() + self.LEASE_SECONDS
                    return aux
        raise PermissionError('Your mix reservation has ended. Choose an available mix.')

    def release(self, token):
        with self.lock:
            self.expire_leases()
            for aux, lease in list(self.leases.items()):
                if secrets.compare_digest(str(token), lease['token']):
                    del self.leases[aux]
                    self.active.pop(aux, None)
                    return

    def catalog(self):
        with self.lock:
            self.expire_leases()
            connected = self.connection_info()['connected']
            return {'connection': self.connection_info(), 'lease_seconds': self.LEASE_SECONDS,
                    'auxes': [{**info, 'occupied': aux in self.leases,
                               'available': connected and info['supported'] and info['name'] is not None and aux not in self.leases}
                              for aux, info in self.auxes.items()]}

    @staticmethod
    def address(ch, aux, field):
        return f'/Input_Channels/{ch}/Aux_Send/{aux}/{FIELDS[field]}'

    def receive(self, packet, source):
        if source[0] != self.config['console_ip']:
            return
        messages = decode(packet)
        with self.lock:
            for address, args in messages:
                self.received += 1
                self.last_address = address
                now = time.monotonic()
                if address == '/Console/Session/!':
                    self.clear()
                    continue
                recognized = False
                if address == '/Console/Name' and len(args) == 1 and isinstance(args[0], str):
                    self.name = args[0][:256]; recognized = True
                elif address == '/Console/Input_Channels' and len(args) == 1 and type(args[0]) is int and 0 <= args[0] <= MAX_INPUTS:
                    count = args[0]
                    if self.input_count is not None and count != self.input_count:
                        self.values.clear(); self.revision += 1
                    self.input_count = count
                    self.inputs = {i: self.inputs.get(i, {'id': i, 'name': None}) for i in range(1, count + 1)}
                    recognized = True
                elif address == '/Console/Aux_Outputs/modes' and len(args) <= MAX_AUXES and all(type(v) is int and 0 <= v <= 8 for v in args):
                    if self.modes is not None and self.modes != args:
                        self.values.clear(); self.revision += 1
                    self.modes = list(args)
                    self.auxes = {i: {'id': i, 'name': self.auxes.get(i, {}).get('name'),
                                     'stereo': mode == 2, 'supported': mode in (1, 2), 'mode': mode}
                                  for i, mode in enumerate(args, 1)}
                    recognized = True
                else:
                    match = re.fullmatch(r'/Input_Channels/(\d+)/Channel_Input/name', address)
                    auxmatch = re.fullmatch(r'/Aux_Outputs/(\d+)/Buss_Trim/name', address)
                    send = re.fullmatch(r'/Input_Channels/(\d+)/Aux_Send/(\d+)/(send_level|send_pan)', address)
                    if match and len(args) == 1 and isinstance(args[0], str) and int(match[1]) in self.inputs:
                        self.inputs[int(match[1])]['name'] = args[0][:256]; recognized = True
                    elif auxmatch and len(args) == 1 and isinstance(args[0], str) and int(auxmatch[1]) in self.auxes:
                        self.auxes[int(auxmatch[1])]['name'] = args[0][:256]; recognized = True
                    elif send and len(args) == 1:
                        ch, aux = int(send[1]), int(send[2])
                        field = next(key for key, name in FIELDS.items() if name == send[3])
                        value = args[0]
                        good = type(value) in (int, float) and math.isfinite(value)
                        good = good and ((-150 <= value <= 10) if field == 'level' else (0 <= value <= 1))
                        if ch in self.inputs and aux in self.auxes and good:
                            self.values[aux, ch, field] = {'value': value, 'time': now}; recognized = True
                if recognized:
                    self.last_rx = now
                    self.last_error = None

    def connection_info(self):
        now = time.monotonic()
        connected = bool(self.last_rx and now - self.last_rx < 12)
        complete = self.input_count is not None and self.modes is not None
        if not self.config['console_ip']:
            status = 'Enter the console IP on this computer’s setup page.'
        elif not connected:
            status = 'Waiting for console OSC replies. Check DiGiCo Pad, IP addresses, ports and firewall.'
        elif not complete:
            status = 'Console replying; discovering input channels and auxes…'
        else:
            status = 'Receiving live console data.'
        return {'connected': connected, 'opened': self.sock is not None, 'discovered': complete, 'console_name': self.name,
                'message': self.last_error or status, 'received_messages': self.received,
                'last_address': self.last_address,
                'seconds_since_reply': round(now - self.last_rx, 1) if self.last_rx else None}

    def snapshot(self, aux):
        with self.lock:
            now = time.monotonic(); self.active[aux] = now
            info = self.connection_info()
            auxinfo = dict(self.auxes.get(aux, {'id': aux, 'name': None, 'stereo': False, 'supported': False}))
            channels = []
            for ch, channel in self.inputs.items():
                item = dict(channel); item['group'] = 'Inputs'
                item['fields'] = {}
                for field in FIELDS:
                    value = self.values.get((aux, ch, field))
                    item['fields'][field] = {'value': value['value'] if value else None,
                        'fresh': bool(value and info['connected'] and now - value['time'] < 30)}
                channels.append(item)
            return {'mode': 'live', 'revision': self.revision, 'connection': info, 'aux': auxinfo,
                    'max_db': self.config['max_db'], 'channels': channels}

    def admin(self):
        with self.lock:
            self.expire_leases()
            result = {'config': {k: v for k, v in self.config.items() if k != 'aux_access'},
                      'connection': self.connection_info(), 'auxes': [],
                      'inputs_discovered': self.input_count, 'input_names_loaded': sum(v['name'] is not None for v in self.inputs.values())}
            for aux, info in self.auxes.items():
                result['auxes'].append({**info, 'occupied': aux in self.leases})
            return result

    def write(self, aux, payload):
        if not isinstance(payload, dict) or set(payload) != {'channel', 'field', 'value', 'revision'}:
            raise ValueError('Expected channel, field, value and revision only.')
        ch, field, value = payload['channel'], payload['field'], payload['value']
        with self.lock:
            if type(payload['revision']) is not int or payload['revision'] != self.revision:
                raise RuntimeError('The console session changed. Refresh your mix before changing a send.')
            if aux not in self.auxes or not self.auxes[aux]['supported']:
                raise RuntimeError('This aux is not available as a mono/stereo monitor aux.')
            if type(ch) is not int or ch not in self.inputs or not isinstance(field, str) or field not in FIELDS:
                raise ValueError('Invalid input or send parameter.')
            if field == 'pan' and not self.auxes[aux]['stereo']:
                raise ValueError('This is a mono aux.')
            if type(value) not in (int, float) or not math.isfinite(value):
                raise ValueError('Value must be a finite number.')
            if field == 'level':
                valid = -50 <= value <= self.config['max_db']
            else:
                valid = 0 <= value <= 1
            if not valid:
                raise ValueError('Send value exceeds its allowed range.')
            cell = self.values.get((aux, ch, field))
            if not self.connection_info()['connected'] or not cell or time.monotonic() - cell['time'] >= 30:
                raise RuntimeError('Current console feedback is missing. Control paused.')
            if self.inputs[ch]['name'] is None or self.auxes[aux]['name'] is None:
                raise RuntimeError('Waiting for console channel and aux names.')
            if not self.sock:
                raise RuntimeError('Console connection is not open.')
            key = (aux, ch, field)
            if time.monotonic() - self.last_writes.get(key, 0) < .08:
                raise RuntimeError('Changes are arriving too quickly. Wait briefly.')
            argument = float(value)
            self.sock.sendto(encode(self.address(ch, aux, field), argument),
                             (self.config['console_ip'], self.config['console_receive_port']))
            self.last_writes[key] = time.monotonic()
            # Only incoming console feedback updates the displayed value.

    def listen(self, sock, stop):
        while not stop.is_set():
            try:
                packet, source = sock.recvfrom(65535)
                if not stop.is_set():
                    self.receive(packet, source)
            except (socket.timeout, ValueError, UnicodeError, IndexError):
                pass
            except OSError:
                return

    def due_queries(self):
        with self.lock:
            now = time.monotonic()
            candidates = [('/Console/Name/?', 3), ('/Console/Channels/?', 5), ('/Console/Aux_Outputs/modes/?', 5)]
            for aux, info in self.auxes.items():
                candidates.append((f'/Aux_Outputs/{aux}/Buss_Trim/name/?', 15 if info['name'] is not None else 2))
            for ch, info in self.inputs.items():
                candidates.append((f'/Input_Channels/{ch}/Channel_Input/name/?', 15 if info['name'] is not None else 2))
            for aux, last in list(self.active.items()):
                if now - last > 15 or aux not in self.auxes:
                    continue
                for ch in self.inputs:
                    for field in FIELDS:
                        if field == 'pan' and not self.auxes[aux]['stereo']:
                            continue
                        candidates.append((self.address(ch, aux, field) + '/?', 4))
            due = []
            for address, interval in candidates:
                if now - self.query_times.get(address, -1000) >= interval:
                    self.query_times[address] = now
                    due.append(address)
            return self.revision, due

    def poll(self, sock, stop):
        while not stop.is_set():
            revision, addresses = self.due_queries()
            for address in addresses:
                if stop.is_set() or revision != self.revision:
                    break
                try:
                    sock.sendto(encode(address), (self.config['console_ip'], self.config['console_receive_port']))
                except OSError as error:
                    with self.lock:
                        self.last_error = str(error)
                    break
                if stop.wait(.002):
                    break
            stop.wait(.25)


def handler(bridge):
    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup(); self.connection.settimeout(5)

        def log_message(self, *args):
            pass

        def local_setup(self):
            host = self.headers.get('Host', '').split(':')[0].lower()
            return self.client_address[0] == '127.0.0.1' and host in ('localhost', '127.0.0.1')

        def reply(self, status, value):
            raw = json.dumps(value, allow_nan=False).encode()
            self.send_response(status); self.send_header('Content-Type', 'application/json')
            self.send_header('Cache-Control', 'no-store'); self.send_header('Content-Length', str(len(raw)))
            self.end_headers(); self.wfile.write(raw)

        def aux(self):
            auth = self.headers.get('Authorization', '')
            if not auth.startswith('Bearer '):
                raise PermissionError('Choose a mix to start a session.')
            return bridge.authorize(auth[7:])

        def do_GET(self):
            path = urlsplit(self.path).path
            if path in ('/api/setup', '/setup', '/setup.js') and not self.local_setup():
                self.reply(403, {'error': 'Open http://localhost:' + str(bridge.config['http_port']) + '/setup on the server computer.'}); return
            if path == '/api/mixes':
                self.reply(200, bridge.catalog()); return
            if path == '/api/setup':
                self.reply(200, bridge.admin()); return
            if path == '/api/state':
                try:
                    with bridge.lock:
                        state = bridge.snapshot(self.aux())
                    self.reply(200, state)
                except PermissionError as error: self.reply(403, {'error': str(error)})
                return
            files = {'/': ('index.html', 'text/html'), '/app.js': ('app.js', 'text/javascript'),
                     '/style.css': ('style.css', 'text/css'), '/setup': ('setup.html', 'text/html'),
                     '/setup.js': ('setup.js', 'text/javascript')}
            if path not in files:
                self.reply(404, {'error': 'Not found'}); return
            name, mime = files[path]; raw = (ROOT / 'web' / name).read_bytes()
            self.send_response(200); self.send_header('Content-Type', mime + '; charset=utf-8')
            self.send_header('Content-Length', str(len(raw))); self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'")
            self.end_headers(); self.wfile.write(raw)

        def do_POST(self):
            path = urlsplit(self.path).path
            if path not in ('/api/send', '/api/setup', '/api/claim', '/api/release'):
                self.reply(404, {'error': 'Not found'}); return
            if self.headers.get('Content-Type') != 'application/json':
                self.reply(415, {'error': 'JSON required'}); return
            try:
                if path == '/api/setup' and not self.local_setup():
                    raise PermissionError('Connection setup is only available on the server computer.')
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= 2048:
                    raise ValueError('Invalid request length.')
                body = json.loads(self.rfile.read(length))
                if path == '/api/setup':
                    with self.server.configuration_lock:
                        bridge.configure(body)
                    self.reply(200, bridge.admin())
                elif path == '/api/claim':
                    if not isinstance(body, dict) or set(body) != {'aux'}:
                        raise ValueError('Choose one aux.')
                    self.reply(200, bridge.claim(body['aux']))
                elif path == '/api/release':
                    auth = self.headers.get('Authorization', '')
                    bridge.release(auth[7:] if auth.startswith('Bearer ') else '')
                    self.reply(200, {'released': True})
                else:
                    with bridge.lock:
                        aux = self.aux()
                        bridge.write(aux, body)
                    self.reply(200, {'status': 'sent; awaiting console feedback'})
            except PermissionError as error: self.reply(403, {'error': str(error)})
            except (ValueError, TypeError, UnicodeError) as error: self.reply(400, {'error': str(error)})
            except (RuntimeError, OSError) as error: self.reply(409, {'error': str(error)})
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default=str(ROOT / 'config.live.json'))
    parser.add_argument('--console-ip', help='Optional console IPv4 address; otherwise use the setup page.')
    parser.add_argument('--stop-file', help=argparse.SUPPRESS)
    parser.add_argument('--status-file', help=argparse.SUPPRESS)
    args = parser.parse_args(); path = Path(args.config)
    config = json.loads(path.read_text()) if path.exists() else dict(DEFAULT)
    if config.get('version') != 3:
        parser.error('Use config.live.json for this live iPad-protocol version. Old /sd configs are incompatible.')
    if args.console_ip:
        config['console_ip'] = args.console_ip
    bridge = Bridge(config, path); bridge.save()
    try: bridge.start()
    except OSError as error: print('Console connection:', error, flush=True)
    server = ThreadingHTTPServer(('0.0.0.0', config['http_port']), handler(bridge))
    server.daemon_threads = True; server.configuration_lock = threading.Lock()
    print(f"Quantum Aux LIVE — setup: http://localhost:{config['http_port']}/setup", flush=True)
    print(f"iPad: http://<computer-LAN-IP>:{config['http_port']} — choose an available mix.", flush=True)
    finished = threading.Event()
    if args.stop_file or args.status_file:
        stop_path = Path(args.stop_file) if args.stop_file else None
        status_path = Path(args.status_file) if args.status_file else None
        def desktop_watch():
            while not finished.is_set():
                if status_path:
                    try:
                        temporary = status_path.with_suffix('.tmp')
                        with bridge.lock:
                            data = {'pid': __import__('os').getpid(), 'port': config['http_port'],
                                    'connection': bridge.connection_info()}
                        temporary.write_text(json.dumps(data), encoding='utf-8')
                        temporary.replace(status_path)
                    except OSError:
                        pass
                if stop_path and stop_path.exists():
                    server.shutdown()
                    return
                finished.wait(.25)
        threading.Thread(target=desktop_watch, daemon=True).start()
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: finished.set(); bridge.stop(); server.server_close()


if __name__ == '__main__':
    main()
