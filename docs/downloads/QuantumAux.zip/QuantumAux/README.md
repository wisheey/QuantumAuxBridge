# Windows quick start (automatic setup)

Extract the ZIP into a writable folder, for example Documents/QuantumAux. Double-click **Start-Windows.vbs**. On Windows 10 or 11, **Start-Windows.bat** is an alternative that starts the same hidden PowerShell launcher directly, without VBScript. Its initial command window closes immediately.

On the first launch, the small status window downloads Python 3.13.16 from python.org (about 11 MB), verifies the Python executable publisher, and prepares a private runtime in `%LOCALAPPDATA%/QuantumAux`. Internet is needed for this first download; subsequent launches reuse the runtime. No manual Python installation, pip packages, PATH changes, or administrator installation is required. Supports Windows 10/11; x64 and 32-bit packages are selected automatically. Windows ARM64 uses the x86 runtime under emulation for Windows 10 compatibility. Windows Script Host and Windows PowerShell/.NET WinForms must be available. Managed policies may block scripts; this launcher does not change persistent execution policy.

The server starts automatically. The local console setup page opens automatically once each successful server start. **Console setup** also opens it manually. **Open mixer** opens the mix picker. Copy a displayed PC LAN URL into Safari on an iPad connected to the same network. Allow Windows Firewall access for the private/control network if prompted. Configure DiGiCo Pad to send to this PC and the configured receive UDP port.

**Hide to tray** or closing the status window keeps the server running. Double-click the tray icon to bring the window back. The tray icon is green once the console UDP connection is opened (the same state as the setup page’s “Connection opened” message), and red before opening, when stopped, or when the web server is not responding. Green means the connection is open; console LIVE feedback is shown separately. The tooltip and status window separately show whether the console is LIVE. **Stop server** gracefully releases the network ports; **Exit server** shuts down the launcher and server. No CMD window stays open. Opening a second launcher is prevented. A used HTTP port produces an error instead of silently attaching to another process.

Keep this folder in place while running. Save your existing `config.live.json` when upgrading; copy it into the extracted folder before starting. Settings remain in that file. **View log** opens `server.log` if startup fails. The runtime is cached separately; no console or mix data is sent to the download site. This is an automatic downloader/launcher package, not a compiled standalone EXE.

All faders include a visible **0 dB** unity line and label. Send limits stay **−50 to +10 dB**, all fills are blue, and send on/off remains removed.

Validation: backend integration tests and desktop stop-file shutdown are checked in the authoring environment. The launcher uses a per-process local status file, with connection-open state tested before live console replies. Browser launching uses Windows shell execution and records failures in server.log. Actual Windows runtime download, publisher validation, WinForms/tray display and physical-console behavior still require verification on Windows; the authoring environment has no Windows runtime.

---

# Quantum Aux — LIVE console server

This version restores the computer server and uses the **DiGiCo Pad / SD–Quantum iPad protocol**. It discovers console inputs and auxes, reads their actual names, and reads/writes input-to-aux send levels in **dB**. Sample names, default levels, demo mode, and the legacy normalized `/sd` command profile have been removed.

A Windows, Mac or Linux computer runs the Python bridge; the iPad opens the mix screen in Safari. Python 3.10+ is the only server dependency. The computer must remain running on the console's control network.

**Hardware status:** the actual live server and browser interaction logic were exercised against a simulated console using real HTTP and UDP sockets. This is not a claim that a physical Quantum 338 was connected or tested. The console is on your local network, which the creation environment cannot access. Use the setup diagnostics below to verify your console's replies.

## Start and connect

1. Extract this ZIP into a new folder. Windows uses the automatic launcher above; install Python 3.10+ only for manual or Mac/Linux use.
2. On Windows double-click `Start-Windows.bat`, or run `python server.py` from this folder. On Mac/Linux run `python3 server.py`.
3. On **that computer**, open `http://localhost:8765/setup`.
4. Enter the **console control-network IPv4 address**, console Receive UDP port, and computer Receive UDP port. Click **Connect and read console**. No configuration-file editing is required.
5. Configure the console as described below. The setup page will show the real console name, the number of channel names received, and discovered aux names and occupancy.
6. On the iPad, join the same network and open `http://COMPUTER-LAN-IP:8765` using the computer's actual LAN IP. Tap any available mix. No access code is required.
7. Wait for the names and send levels to load. Controls enable only after their real values and channel/aux labels have arrived. There is no fallback to demo values.

`localhost` on an iPad means the iPad itself, so use the computer's LAN address there. Find the computer's address with `ipconfig` on Windows or Network settings on Mac. Connection setup remains available only through localhost on the computer. The mix picker is open to everyone on the network.

The connection is saved to `config.live.json`. On future launches the server reconnects automatically. The previous `config.local.json` and native iPad project are not used. Existing aux codes are removed automatically when this version loads the configuration. To upgrade, stop the old server, replace the app files, keep your existing `config.live.json`, then restart.

## Console External Control

On your Quantum console, enable External Control and create/enable a **DiGiCo Pad** device addressed to the computer's LAN IP. Load/enable the appropriate iPad command set for your console software, following DiGiCo's instructions. Do not use the legacy Other OSC `/sd` command set for this version.

| Setting on the console | Corresponding setup-page field | Example |
| --- | --- | --- |
| Console local IP | Console IPv4 address | Your desk's actual control IP |
| Device IP | The computer's LAN IP | Your computer's actual IP |
| Console **Receive** port | Console Receive UDP port | 8000 |
| Console **Send** port | Console Send / computer Receive UDP port | 9000 |

Ports are examples and must match your settings. Use distinct ports/device entries as required when other iPad controllers are present. Enable both the external device and External Control itself.

Allow inbound **UDP 9000** (or your chosen receive port) and **TCP 8765** through the computer firewall. The iPad, computer and mixer need network routes to each other; Wi-Fi client isolation can prevent this. The bridge listens on the chosen UDP port and sends from that same port.

## What comes from the console

- Input channel count.
- Aux list and mono/stereo modes.
- Input channel names, including later renames.
- Aux names, including later renames.
- Current input-to-selected-aux send levels in dB.
- Stereo send pan, when returned by the console.

Nothing writes names back to the desk. A deliberately blank console label appears as “unnamed on console”; a label that has not arrived is marked as waiting. All discovered inputs are shown. Aux masters and main/input fader levels are not displayed or controlled.

Input names and aux names are refreshed about every 15 seconds, and unsolicited console updates are also accepted. Send values are queried only for auxes currently in use, nominally every four seconds. OSC query pacing limits bursts. Incoming values update the browser on its next one-second refresh.

A startup metadata read does not send any fader or other parameter changes. Connecting and opening a mix is read-only until a performer moves a control.

## Console-style interface

The mix screen follows the supplied visual reference: tall charcoal channel strips, blue level fills, silver fader handles, large two-decimal dB readouts above, and light channel-name panels below. Eight strips fit across a landscape iPad-sized screen; narrower screens show fewer. Swipe sideways or use the arrow buttons for further channels. Pointer dragging uses the visible fader geometry with pointer capture; the native range retains keyboard accessibility, and its dB mapping and +10 dB limit are unchanged.

Tap **Pan** to show/hide stereo pan controls. All strips are blue; earlier browser color preferences are ignored. Unknown levels have no colored fill or handle until a value is received. Live console names remain the labels.

The updated frontend logic was checked for layout structure, numeric display, fader values, lock state and cosmetic-only actions. Browser rendering was unavailable in the build environment; confirm the finished layout and touch behavior in iPad Safari.

## Mixing behavior

The public mix picker lists every discovered aux. Any user can choose an available mono/stereo mix without a code. Selecting it creates an exclusive reservation on the server. An occupied mix displays **IN USE** and cannot be selected by another session, including when two users try at the same time. Mono/stereo modes 1 and 2 are supported; other returned modes remain listed but not controllable.

- **Leave mix** immediately releases the reservation when the server receives the request.
- The browser's normal state refresh renews its reservation every second.
- Closing the page, losing Wi-Fi, or suspending Safari releases the mix after **30 seconds without contact**. A brief interruption keeps it reserved during that grace period.
- Refreshing the same tab resumes its reservation while it remains valid. After expiry, the user returns to the picker and must select an available mix again. The app does not automatically take a mix back from its new owner.
- The server rejects all old-session writes after release, expiry or reassignment. A late release from a former owner cannot release a new owner's reservation.

There are no user-entered credentials. The app stores an automatic private reservation token in the browser tab's session storage so it can prove ownership. It is not listed in the public picker or engineer setup. Duplicated tabs may share that browser session; the reservation represents a browser session rather than a verified human identity. Reservations coordinate users of this server only; they cannot block control from the physical console or another OSC application.

Faders show actual returned dB values. The app sends levels from **−50 dB to +10 dB**, in 0.5 dB steps; the bottom position sends −50 dB. Outgoing values outside that range are rejected. Console feedback below −50 dB is still displayed accurately, with the handle at the bottom until adjusted. This is the app’s slider layout, not a claim to reproduce DiGiCo’s physical fader taper.

The send on/off button and its OSC reads/writes have been removed. Enable the send on the console when needed. Stereo pan uses the returned 0–1 value with 0.5 as center and stays disabled until valid readback arrives.

Sending UDP is not an acknowledgement. Displayed confirmed values come only from console replies. A change without matching feedback is reported after about 5.5 seconds. No control changes are queued for replay after loss of the web connection.

Individual parameters pause after 30 seconds without fresh readback. The whole console connection is marked offline after 12 seconds without a recognized reply. Network/console status is separate from the browser's connection to the bridge.

A console session notification, server restart or connection reconfiguration clears reservations and returns users to the picker. A discovered channel/bus structure change invalidates cached levels and old write requests; retained sessions lock until checked and unlocked. Check the aux and channel names after loading a show.

## If nothing loads

The setup page shows received OSC message count and the last OSC address. Use these to narrow the issue:

| What you see | Check |
| --- | --- |
| No received messages | Console/computer IPs, both port directions, enabled DiGiCo Pad device, External Control, firewall, network isolation |
| Addresses beginning `/sd/` | Wrong command profile; this app expects the iPad addresses without `/sd` |
| Console replies, no input/aux discovery | Confirm the appropriate iPad command set is loaded for your Quantum firmware |
| Names load, levels are waiting | Open the assigned aux on an iPad; only active aux sends are polled. Check that the console returns the parameter queries below |
| Levels work but pan waits | Pan has not returned valid data. Check command support for the installed firmware |
| Cannot bind receive port | Another application is using that port; select a free one and match the console Send port |
| “Unsupported bus mode” | The reported mode is outside the mono/stereo profile handled by this version |

Do not bypass stale-feedback checks to hide a connectivity problem. If the profile differs on your console, the bridge needs the actual returned messages or the matching DiGiCo protocol documentation to adjust it correctly. Helpful troubleshooting details are console software version, the External Control device screenshot, and the setup page's last address/message count.

## Wire protocol and implementation basis

This version follows the discovery/readback behavior implemented in the maintained [OSCWebMixer2](https://github.com/castles/OSCWebMixer2) SD/Quantum project. It is a separate Python implementation. In particular, it uses the iPad protocol rather than the prior `/sd` normalized assumptions.

| Query (no arguments) | Expected response |
| --- | --- |
| `/Console/Name/?` | `/Console/Name` with string |
| `/Console/Channels/?` | `/Console/Input_Channels` with integer count, among other replies |
| `/Console/Aux_Outputs/modes/?` | `/Console/Aux_Outputs/modes` with integer arguments, one per aux |
| `/Input_Channels/N/Channel_Input/name/?` | Same path without `/?`, string |
| `/Aux_Outputs/A/Buss_Trim/name/?` | Same path without `/?`, string |
| `/Input_Channels/N/Aux_Send/A/send_level/?` | Same path without `/?`, float dB |
| `/Input_Channels/N/Aux_Send/A/send_pan/?` | Same path without `/?`, float 0–1 |

Writes use the corresponding parameter address without `/?`: level and pan are OSC float. Session invalidation listens for `/Console/Session/!`. This is an interoperability implementation based on observable open-source protocol use, not vendor certification for every firmware release.

Official console configuration references: [DiGiCo SD & Quantum software reference](https://digico.biz/wp-content/uploads/2022/03/SD-Quantum-Software-Reference-Issue-E-V1528.pdf), External Control section; [DiGiCo Quantum iPad app](https://digico.biz/apps/quantum-series-core2-app/).

## Tests and limits

Run `python -m unittest -v test_bridge.py` (or `python3` on Mac/Linux). Fifteen integration tests cover discovery, names, dB readback, renamed labels, aux-scoped writes and feedback, missing/stale data, invalid requests, session changes, setup privacy, reconnect/persistence, source filtering, absence of fake startup data, simultaneous claim races, release, expiry/reassignment, old-owner rejection, heartbeat renewal, +10 dB write/readback, migration of the old 0 dB limit, and rejection of on/off commands. The simulated console exists only in the test file; the app itself has no demo mode.

Frontend logic was exercised with a mock DOM against the live HTTP/UDP path, including names, dB display, fader acknowledgement, lock, search, rename rendering, the open mix picker, occupied-mix rejection and release. Actual iPad/Safari visual and touch testing, and a physical Quantum 338 test, remain outstanding.

Use a trusted control network. HTTP/OSC traffic is not encrypted; do not publish the server to the internet. Very large numbers of simultaneously active auxes increase the polling cycle and should be load-tested on the actual desk. Multichannel surround bus control, audio meters, scene control, preamp controls, EQ, native iPad packaging and automatic router configuration are not implemented.

Stop with the launcher’s Stop/Exit buttons, or Ctrl+C for manual command-line use. App files are `server.py`, `osc.py` and `web/`; no third-party Python dependencies are required.

## Quantum family compatibility

The bridge discovers inputs and aux buses from the desk instead of selecting a fixed Quantum 338 layout. Discovery accepts up to 512 inputs and 256 aux/bus entries, including the Quantum 852 capacity of 384 inputs and 192 buses. Actual counts, names and values always come from the console.

Quantum 112, 225, 326, 338, 5, 7 and 852, including Pulse and theatre/broadcast variants, are protocol-compatibility targets, not a hardware-certified list. Each console must expose the DiGiCo Pad SD/Quantum OSC query and send commands documented above. Enable External Control, select DiGiCo Pad and load the matching console's iPad commands. Firmware or command-map differences may require adaptation; universal compatibility is not verified. Only mono/stereo aux sends are supported; surround buses and subgroup control remain excluded.

Large-console discovery and high-numbered aux/input writes are covered by automated protocol tests. Physical console operation, Windows 10/11 launch and maximum simultaneous-mix capacity require on-device validation. A large number of active mixes can lengthen polling cycles; stale controls remain paused.

Official references: https://digico.biz/consoles/quantum852/ and https://docs.python.org/3.13/using/windows.html
