"""Tests exercise the actual live bridge using a simulated DiGiCo Pad UDP peer."""
import json, socket, struct, threading, time, unittest, tempfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request, urllib.error
from http.server import ThreadingHTTPServer
from server import Bridge, DEFAULT, handler
from osc import encode, decode, string


def packet(address, values):
    if len(values) <= 1: return encode(address, values[0] if values else None)
    return string(address) + string(',' + 'i' * len(values)) + b''.join(struct.pack('>i', v) for v in values)


def eventually(check):
    end = time.monotonic() + 4
    while time.monotonic() < end:
        if check(): return
        time.sleep(.01)
    raise AssertionError('Timed out waiting for console feedback')


class Console:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(('127.0.0.1', 0)); self.sock.settimeout(.1)
        self.port = self.sock.getsockname()[1]; self.stopped = False
        self.writes = []; self.queries = []; self.target = None; self.values = {}
        self.thread = threading.Thread(target=self.run, daemon=True); self.thread.start()
    def emit(self, address, values): self.sock.sendto(packet(address, values), self.target)
    def run(self):
        while not self.stopped:
            try: data, self.target = self.sock.recvfrom(65535)
            except socket.timeout: continue
            except OSError: return
            for address, args in decode(data):
                if address.endswith('/?') and not args:
                    self.queries.append(address); base = address[:-2]
                    if base == '/Console/Name': self.emit(base, ['Bench Quantum'])
                    elif base == '/Console/Channels': self.emit('/Console/Input_Channels', [2])
                    elif base == '/Console/Aux_Outputs/modes': self.emit(base, [1, 2])
                    elif base.endswith('/Channel_Input/name'): self.emit(base, ['Console vocal' if '/1/' in base else 'Console guitar'])
                    elif base.endswith('/Buss_Trim/name'): self.emit(base, ['Singer IEM' if '/1/' in base else 'Drummer IEM'])
                    elif base.endswith('/send_level'): self.emit(base, self.values.get(base, [-12.5]))
                    elif base.endswith('/send_on'): self.emit(base, self.values.get(base, [1]))
                    elif base.endswith('/send_pan'): self.emit(base, self.values.get(base, [.5]))
                else: self.writes.append((address, args)); self.values[address] = args; self.emit(address, args)
    def close(self):
        self.stopped = True; self.sock.close(); self.thread.join(timeout=1)


class Integration(unittest.TestCase):
    def setUp(self):
        self.console = Console()
        reserve = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); reserve.bind(('127.0.0.1', 0))
        port = reserve.getsockname()[1]; reserve.close()
        self.bridge = Bridge({**DEFAULT, 'console_ip': '127.0.0.1', 'console_receive_port': self.console.port, 'bridge_receive_port': port, 'aux_access': {}})
        self.bridge.start()
        self.http = ThreadingHTTPServer(('127.0.0.1', 0), handler(self.bridge)); self.http.configuration_lock = threading.Lock()
        threading.Thread(target=self.http.serve_forever, daemon=True).start()
        self.url = f'http://127.0.0.1:{self.http.server_port}'
        eventually(lambda: self.bridge.auxes.get(1, {}).get('name') == 'Singer IEM' and self.bridge.inputs.get(2, {}).get('name') == 'Console guitar')
        self.code = self.bridge.claim(1)['token']
    def tearDown(self):
        self.bridge.stop(); self.console.close(); self.http.shutdown(); self.http.server_close()
    def request(self, path, body=None, code=None, host=None):
        headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + (self.code if code is None else code)}
        if host: headers['Host'] = host
        request = urllib.request.Request(self.url + path, headers=headers, data=json.dumps(body).encode() if body is not None else None)
        try:
            with urllib.request.urlopen(request, timeout=2) as response: return response.status, json.load(response)
        except urllib.error.HTTPError as response: return response.code, json.load(response)
    def sync(self, aux=1):
        self.bridge.snapshot(aux); eventually(lambda: (aux, 1, 'level') in self.bridge.values)
    def payload(self, **kw): return {'channel': 1, 'field': 'level', 'value': -6.0, 'revision': self.bridge.revision, **kw}
    def test_discovery_and_db_readback(self):
        self.sync(); status, state = self.request('/api/state')
        self.assertEqual(status, 200); self.assertEqual(state['aux']['name'], 'Singer IEM')
        self.assertEqual([c['name'] for c in state['channels']], ['Console vocal', 'Console guitar'])
        self.assertEqual(state['channels'][0]['fields']['level']['value'], -12.5)
        self.assertTrue(state['channels'][0]['fields']['level']['fresh'])
        self.assertEqual(state['connection']['console_name'], 'Bench Quantum')
        self.assertFalse(state['aux']['stereo']); self.assertTrue(self.bridge.auxes[2]['stereo'])
        self.assertTrue(all(not q.startswith('/sd/') for q in self.console.queries)); self.assertEqual(self.console.writes, [])
    def test_aux_scoped_write_and_confirmation(self):
        self.sync(2)
        second = self.bridge.claim(2)['token']
        self.assertEqual(self.request('/api/send', self.payload(value=-7.5), code=second)[0], 200)
        eventually(lambda: self.bridge.values[2, 1, 'level']['value'] == -7.5)
        self.assertEqual(self.console.writes[-1], ('/Input_Channels/1/Aux_Send/2/send_level', [-7.5]))
        self.assertEqual(self.request('/api/send', {**self.payload(), 'aux': 1}, code=second)[0], 400)
    def test_renamed_channels_and_auxes(self):
        self.console.emit('/Input_Channels/1/Channel_Input/name', ['Lead <vocal>'])
        self.console.emit('/Aux_Outputs/1/Buss_Trim/name', ['New mix name'])
        eventually(lambda: self.bridge.inputs[1]['name'] == 'Lead <vocal>' and self.bridge.auxes[1]['name'] == 'New mix name')
        state = self.request('/api/state')[1]
        self.assertEqual(state['channels'][0]['name'], 'Lead <vocal>'); self.assertEqual(state['aux']['name'], 'New mix name')
    def test_no_feedback_and_stale_feedback(self):
        self.assertEqual(self.request('/api/send', self.payload())[0], 409)
        self.sync(); self.bridge.values[1, 1, 'level']['time'] = time.monotonic() - 40
        self.assertEqual(self.request('/api/send', self.payload())[0], 409); self.assertEqual(self.console.writes, [])
    def test_invalid_auth_values_and_parameters(self):
        self.assertEqual(self.request('/api/state', code='wrong')[0], 403)
        for field, value in [('fader', -6), ('mute', 1), ('level', 10.5), ('level', -151), ('level', float('nan')), ('level', True), ('on', .2), ('pan', .5)]:
            self.assertEqual(self.request('/api/send', self.payload(field=field, value=value))[0], 400)
        self.assertEqual(self.console.writes, [])
    def test_session_change_rejects_old_requests(self):
        self.sync(); old = self.payload()
        self.bridge.receive(encode('/Console/Session/!'), ('127.0.0.1', self.console.port))
        self.assertEqual(self.bridge.inputs, {}); self.assertEqual(self.bridge.values, {})
        self.assertEqual(self.request('/api/send', old)[0], 403)
    def test_admin_privacy_and_rebinding(self):
        self.assertEqual(self.request('/api/setup', host='evil.example')[0], 403)
        self.assertEqual(len(self.request('/api/setup')[1]['auxes']), 2)
        self.assertNotIn('access_code', self.request('/api/state')[1]['aux'])
        self.assertEqual(self.request('/config.live.json')[0], 404)
    def test_setup_reconnects_and_persists_configuration(self):
        with tempfile.TemporaryDirectory() as directory:
            self.bridge.path = Path(directory) / 'config.live.json'
            body = {key: self.bridge.config[key] for key in ('console_ip', 'console_receive_port', 'bridge_receive_port')}
            self.assertEqual(self.request('/api/setup', body)[0], 200)
            eventually(lambda: self.bridge.auxes.get(1, {}).get('name') == 'Singer IEM')
            self.assertEqual(json.loads(self.bridge.path.read_text())['max_db'], 10.0)
            with self.assertRaises(PermissionError): self.bridge.authorize(self.code)
            self.bridge.path = None

    def test_atomic_claim_only_one_simultaneous_user_wins(self):
        gate = threading.Barrier(2)
        def attempt():
            gate.wait()
            return self.request('/api/claim', {'aux': 2}, code='')
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: attempt(), range(2)))
        self.assertEqual(sorted(status for status, _ in results), [200, 409])
        catalog = self.request('/api/mixes', code='')[1]
        self.assertTrue(all(aux['occupied'] for aux in catalog['auxes']))
        self.assertNotIn('token', json.dumps(catalog))

    def test_leave_releases_mix_and_invalidates_old_owner(self):
        self.assertEqual(self.request('/api/release', {})[0], 200)
        self.assertEqual(self.request('/api/state')[0], 403)
        status, lease = self.request('/api/claim', {'aux': 1}, code='')
        self.assertEqual(status, 200)
        self.assertNotEqual(lease['token'], self.code)
        self.assertEqual(self.request('/api/state', code=lease['token'])[0], 200)

    def test_expiry_reassignment_and_old_owner_cannot_write_or_release(self):
        self.sync()
        with self.bridge.lock:
            self.bridge.leases[1]['expires'] = time.monotonic() - 1
        status, lease = self.request('/api/claim', {'aux': 1}, code='')
        self.assertEqual(status, 200)
        self.assertEqual(self.request('/api/send', self.payload())[0], 403)
        self.request('/api/release', {})
        self.assertEqual(self.request('/api/state', code=lease['token'])[0], 200)
        self.assertEqual(self.request('/api/claim', {'aux': 1}, code='')[0], 409)

    def test_state_heartbeat_renews_reservation(self):
        self.bridge.leases[1]['expires'] = time.monotonic() + 1
        self.assertEqual(self.request('/api/state')[0], 200)
        self.assertGreater(self.bridge.leases[1]['expires'] - time.monotonic(), 29)

    def test_plus_ten_db_write_and_no_on_off_support(self):
        self.sync()
        self.assertEqual(self.request('/api/send', self.payload(value=10.0))[0], 200)
        eventually(lambda: self.bridge.values[1, 1, 'level']['value'] == 10.0)
        self.assertEqual(self.request('/api/send', self.payload(field='on', value=1))[0], 400)
        self.assertFalse(any('/send_on' in query for query in self.console.queries))
        self.assertNotIn('on', self.bridge.snapshot(1)['channels'][0]['fields'])
        old = Bridge({**DEFAULT, 'max_db': 0.0})
        self.assertEqual(old.config['max_db'], 10.0)

    def test_source_validation_and_malformed_packet(self):
        self.bridge.receive(encode('/Aux_Outputs/1/Buss_Trim/name', 'spoof'), ('192.0.2.8', 1234))
        self.assertEqual(self.bridge.auxes[1]['name'], 'Singer IEM')
        with self.assertRaises(ValueError): decode(b'bad')
    def test_no_fake_data_before_connection(self):
        bridge = Bridge({**DEFAULT, 'aux_access': {}}); state = bridge.snapshot(1)
        self.assertEqual(state['channels'], []); self.assertIsNone(state['aux']['name'])
        self.assertFalse(state['connection']['connected']); self.assertIsNone(bridge.sock)

class LargeQuantum(unittest.TestCase):
    def test_large_engine_discovery_and_high_send(self):
        from unittest.mock import Mock
        bridge = Bridge({**DEFAULT, 'console_ip': '127.0.0.1'})
        source = ('127.0.0.1', 8000)
        def feed(address, values): bridge.receive(packet(address, values), source)
        feed('/Console/Input_Channels', [384])
        feed('/Console/Aux_Outputs/modes', [2] * 192)
        feed('/Input_Channels/384/Channel_Input/name', ['Last input'])
        feed('/Aux_Outputs/192/Buss_Trim/name', ['Last aux'])
        feed('/Input_Channels/384/Aux_Send/192/send_level', [-12.0])
        self.assertEqual(len(bridge.inputs), 384)
        self.assertEqual(len(bridge.auxes), 192)
        token = bridge.claim(192)['token']
        self.assertTrue(token)
        with self.assertRaises(RuntimeError): bridge.claim(192)
        bridge.sock = Mock()
        bridge.write(192, {'channel': 384, 'field': 'level', 'value': 10.0, 'revision': bridge.revision})
        outgoing = bridge.sock.sendto.call_args[0][0]
        self.assertEqual(list(decode(outgoing)), [('/Input_Channels/384/Aux_Send/192/send_level', [10.0])])
        feed('/Input_Channels/384/Aux_Send/192/send_level', [10.0])
        self.assertEqual(bridge.snapshot(192)['channels'][-1]['fields']['level']['value'], 10.0)
        feed('/Console/Input_Channels', [99999])
        self.assertEqual(len(bridge.inputs), 384)

if __name__ == '__main__': unittest.main(verbosity=2)
